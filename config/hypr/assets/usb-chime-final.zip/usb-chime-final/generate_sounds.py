#!/usr/bin/env python3
"""
generate_sounds.py
------------------
Synthesizes Windows 10/11-style USB connect/disconnect chimes.
Modern aesthetic: clean sine tones, short duration, soft attack,
quick decay — minimal and polished.
Run once during install.
"""
import numpy as np
import wave
import os

RATE    = 44100
OUT_DIR = os.path.expanduser("~/.local/share/usb-chime")


def make_tone(freq, duration, volume=0.45, attack=0.004, decay=0.18):
    """Single sine tone with ADSR envelope and subtle 2nd harmonic."""
    t    = np.linspace(0, duration, int(RATE * duration), False)
    data = (
        1.00 * np.sin(2 * np.pi * freq * 1 * t) +
        0.10 * np.sin(2 * np.pi * freq * 2 * t)
    )
    env      = np.ones(len(t))
    a, d     = int(attack * RATE), int(decay * RATE)
    env[:a]  = np.linspace(0, 1, a)
    env[-d:] = np.linspace(1, 0, d)
    return data * env * volume


def save_stereo_wav(filepath, data):
    data    = np.clip(data, -1, 1)
    samples = (data * 32767).astype(np.int16)
    stereo  = np.column_stack([samples, samples])
    with wave.open(filepath, 'w') as wf:
        wf.setnchannels(2)
        wf.setsampwidth(2)
        wf.setframerate(RATE)
        wf.writeframes(stereo.tobytes())
    print(f"  Saved: {filepath}")


def main():
    os.makedirs(OUT_DIR, exist_ok=True)

    total = int(RATE * 0.55)
    gap   = int(0.03 * RATE)

    # Connect: C6 (1047Hz) -> E6 (1319Hz) — clean, bright, rising
    connect = np.zeros(total)
    t1 = make_tone(1046.50, 0.14, volume=0.42, attack=0.003, decay=0.08)
    t2 = make_tone(1318.51, 0.22, volume=0.40, attack=0.003, decay=0.16)
    pos2 = len(t1) + gap
    connect[:len(t1)]          += t1
    connect[pos2:pos2+len(t2)] += t2
    save_stereo_wav(os.path.join(OUT_DIR, "connect.wav"), connect)

    # Disconnect: G5 (784Hz) -> D5 (587Hz) — soft, descending, brief
    disconnect = np.zeros(total)
    t1d = make_tone(783.99, 0.13, volume=0.38, attack=0.003, decay=0.08)
    t2d = make_tone(587.33, 0.20, volume=0.34, attack=0.003, decay=0.16)
    disconnect[:len(t1d)]          += t1d
    disconnect[pos2:pos2+len(t2d)] += t2d
    save_stereo_wav(os.path.join(OUT_DIR, "disconnect.wav"), disconnect)

    print("Sound files ready.")


if __name__ == "__main__":
    main()
