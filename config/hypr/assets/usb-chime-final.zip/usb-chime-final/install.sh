#!/usr/bin/env bash
# ================================================================
#  USB Chime — Installer
#  Windows 10/11-style sounds + desktop notifications on USB events
#  Works on Omarchy, Arch, Ubuntu/Debian and any systemd distro
# ================================================================
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_DIR="$HOME/.local/bin"
SHARE_DIR="$HOME/.local/share/usb-chime"
SERVICE_DIR="$HOME/.config/systemd/user"

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║        USB Chime  —  Installer           ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# ── 1. Dependencies ───────────────────────────────────────────
echo "[1/5] Checking dependencies..."

if ! command -v python3 &>/dev/null; then
    echo "ERROR: python3 not found. Please install it first."
    exit 1
fi

if ! python3 -c "import numpy" 2>/dev/null; then
    echo "  → numpy not found, installing..."
    pip install numpy --break-system-packages -q \
        || pip install numpy -q \
        || { echo "ERROR: Could not install numpy. Run: pip install numpy"; exit 1; }
fi
echo "  ✓ python3 + numpy"

# Detect audio player
PLAYER=""
for p in paplay pw-play aplay ffplay mpv; do
    if command -v "$p" &>/dev/null; then
        PLAYER="$p"
        break
    fi
done

if [ -z "$PLAYER" ]; then
    echo ""
    echo "  ⚠ No audio player found!"
    echo "  Install one with:"
    echo "    Arch/Omarchy : sudo pacman -S ffmpeg"
    echo "    Ubuntu/Debian: sudo apt install ffmpeg"
    echo ""
    read -rp "  Continue anyway? [y/N] " ans
    [[ "$ans" =~ ^[Yy]$ ]] || exit 1
else
    echo "  ✓ Audio player: $PLAYER"
fi

# Check notify-send for desktop notifications
if command -v notify-send &>/dev/null; then
    echo "  ✓ Desktop notifications: notify-send found"
else
    echo "  ⚠ notify-send not found — notifications will be disabled."
    echo "    To enable, install libnotify:"
    echo "      Arch/Omarchy : sudo pacman -S libnotify"
    echo "      Ubuntu/Debian: sudo apt install libnotify-bin"
fi

# ── 2. Generate sounds ────────────────────────────────────────
echo "[2/5] Generating chime sounds (Windows 10/11 style)..."
mkdir -p "$SHARE_DIR"
python3 "$SCRIPT_DIR/generate_sounds.py"

# ── 3. Install daemon ─────────────────────────────────────────
echo "[3/5] Installing daemon..."
mkdir -p "$BIN_DIR"
cp "$SCRIPT_DIR/usb-chime-daemon.py" "$BIN_DIR/usb-chime-daemon.py"
chmod +x "$BIN_DIR/usb-chime-daemon.py"
echo "  ✓ $BIN_DIR/usb-chime-daemon.py"

# ── 4. Install & start service ────────────────────────────────
echo "[4/5] Enabling systemd user service..."
mkdir -p "$SERVICE_DIR"
cp "$SCRIPT_DIR/usb-chime.service" "$SERVICE_DIR/usb-chime.service"
systemctl --user daemon-reload
systemctl --user enable usb-chime.service
systemctl --user restart usb-chime.service
sleep 1
STATUS=$(systemctl --user is-active usb-chime.service 2>/dev/null || echo "unknown")
echo "  ✓ Service status: $STATUS"

# ── 5. Done ───────────────────────────────────────────────────
echo "[5/5] All done!"
echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  USB Chime is running!  Plug in any USB to test it. 🔔  ║"
echo "║                                                          ║"
echo "║  Status : systemctl --user status usb-chime             ║"
echo "║  Logs   : tail -f ~/.local/share/usb-chime/usb-chime.log║"
echo "║  Uninstall: bash uninstall.sh                            ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
