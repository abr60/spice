#!/usr/bin/env bash
# ================================================================
#  USB Chime — Uninstaller
#  Removes the service, daemon, sounds, and logs completely
# ================================================================

BIN_DIR="$HOME/.local/bin"
SHARE_DIR="$HOME/.local/share/usb-chime"
SERVICE_DIR="$HOME/.config/systemd/user"
SERVICE_FILE="$SERVICE_DIR/usb-chime.service"
DAEMON="$BIN_DIR/usb-chime-daemon.py"

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║        USB Chime  —  Uninstaller         ║"
echo "╚══════════════════════════════════════════╝"
echo ""

read -rp "This will remove USB Chime completely. Continue? [y/N] " ans
[[ "$ans" =~ ^[Yy]$ ]] || { echo "Aborted."; exit 0; }

echo ""

# ── Stop & disable service ────────────────────────────────────
echo "[1/4] Stopping and disabling service..."
if systemctl --user is-active usb-chime.service &>/dev/null; then
    systemctl --user stop usb-chime.service
    echo "  ✓ Stopped"
else
    echo "  · Service was not running"
fi

if systemctl --user is-enabled usb-chime.service &>/dev/null; then
    systemctl --user disable usb-chime.service
    echo "  ✓ Disabled"
fi

# ── Remove service file ───────────────────────────────────────
echo "[2/4] Removing service file..."
if [ -f "$SERVICE_FILE" ]; then
    rm -f "$SERVICE_FILE"
    systemctl --user daemon-reload
    echo "  ✓ Removed: $SERVICE_FILE"
else
    echo "  · Not found: $SERVICE_FILE"
fi

# ── Remove daemon script ──────────────────────────────────────
echo "[3/4] Removing daemon..."
if [ -f "$DAEMON" ]; then
    rm -f "$DAEMON"
    echo "  ✓ Removed: $DAEMON"
else
    echo "  · Not found: $DAEMON"
fi

# ── Remove sounds, logs, data dir ────────────────────────────
echo "[4/4] Removing sound files and logs..."
if [ -d "$SHARE_DIR" ]; then
    rm -rf "$SHARE_DIR"
    echo "  ✓ Removed: $SHARE_DIR"
else
    echo "  · Not found: $SHARE_DIR"
fi

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║  USB Chime fully removed. Goodbye! 👋    ║"
echo "╚══════════════════════════════════════════╝"
echo ""
