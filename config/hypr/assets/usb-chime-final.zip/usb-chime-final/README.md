# USB Chime 🔔
Windows 10/11-style sounds + desktop notifications when you plug/unplug USB devices on Linux.
Works on Omarchy, Arch, Ubuntu, Debian — any systemd-based distro.

## Install
```bash
bash install.sh
```
That's it. Plug in any USB device to test.

## Uninstall
```bash
bash uninstall.sh
```

## Useful commands
```bash
# Check it's running
systemctl --user status usb-chime

# Watch live USB events
tail -f ~/.local/share/usb-chime/usb-chime.log

# Restart after changes
systemctl --user restart usb-chime

# Temporarily stop (survives reboot disabled)
systemctl --user stop usb-chime
```

## Requirements
- Python 3 + numpy (auto-installed if missing)
- One of: `paplay`, `pw-play`, `aplay`, `ffplay`, `mpv`
  - Arch/Omarchy: `sudo pacman -S ffmpeg`
  - Ubuntu/Debian: `sudo apt install ffmpeg`
- `notify-send` for desktop notifications (optional but recommended)
  - Arch/Omarchy: `sudo pacman -S libnotify`
  - Ubuntu/Debian: `sudo apt install libnotify-bin`

## Files installed
| Path | Purpose |
|------|---------|
| `~/.local/bin/usb-chime-daemon.py` | Background daemon |
| `~/.local/share/usb-chime/connect.wav` | Connect chime (modern) |
| `~/.local/share/usb-chime/disconnect.wav` | Disconnect chime (modern) |
| `~/.local/share/usb-chime/usb-chime.log` | Event log |
| `~/.config/systemd/user/usb-chime.service` | Systemd service |

## Notifications
Desktop popups appear for **all** USB devices on both connect and disconnect,
showing the device name (e.g. "Logitech USB Receiver", "SanDisk Ultra").
Notifications require `notify-send` (libnotify). If not installed, sounds
still work but no popup will appear.
