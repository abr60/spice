#!/usr/bin/env python3
"""
usb-chime-daemon.py
-------------------
Monitors USB device connections/disconnections and:
  - Plays Windows 10/11-style chimes on plug / unplug
  - Shows a desktop notification (notify-send) for both events

Runs silently in the background via a systemd user service.

Disconnect fix: udev strips device properties before the remove event
fires, so we track connected devices by DEVPATH at connect time and
match on that path at disconnect time.
"""

import subprocess
import sys
import os
import logging
import signal

# ── Paths ──────────────────────────────────────────────────────────────────
SOUND_DIR      = os.path.expanduser("~/.local/share/usb-chime")
CONNECT_WAV    = os.path.join(SOUND_DIR, "connect.wav")
DISCONNECT_WAV = os.path.join(SOUND_DIR, "disconnect.wav")
LOG_FILE       = os.path.join(SOUND_DIR, "usb-chime.log")

# ── Logging ────────────────────────────────────────────────────────────────
os.makedirs(SOUND_DIR, exist_ok=True)
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s  %(levelname)s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("usb-chime")


def find_player():
    """Return the best available audio player command."""
    for cmd in ["paplay", "pw-play", "aplay", "ffplay", "mpv"]:
        if subprocess.run(["which", cmd], capture_output=True).returncode == 0:
            return cmd
    return None


def has_notify_send():
    """Check if notify-send is available."""
    return subprocess.run(["which", "notify-send"], capture_output=True).returncode == 0


def notify(summary, body, icon):
    """
    Send a desktop notification non-blocking.
    Passes DBUS_SESSION_BUS_ADDRESS from environment so notify-send
    works inside a systemd user service.
    """
    env = os.environ.copy()
    try:
        subprocess.Popen(
            [
                "notify-send",
                "--urgency=normal",
                "--expire-time=4000",
                f"--icon={icon}",
                summary,
                body,
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            env=env,
        )
    except Exception as e:
        log.warning(f"notify-send failed: {e}")


def play(wav_path, player):
    """Play a WAV file non-blocking (fire and forget)."""
    if not os.path.isfile(wav_path):
        log.warning(f"Sound file missing: {wav_path}")
        return
    try:
        if player == "ffplay":
            subprocess.Popen(
                ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", wav_path],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )
        elif player == "mpv":
            subprocess.Popen(
                ["mpv", "--no-video", "--really-quiet", wav_path],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )
        else:  # paplay / pw-play / aplay
            subprocess.Popen(
                [player, wav_path],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )
    except Exception as e:
        log.error(f"Playback failed ({player}): {e}")


def is_real_usb_device(props: dict) -> bool:
    """
    Returns True for genuine plug-and-play USB peripherals.
    Rejects hubs, root controllers, and devices without a vendor ID.
    """
    if props.get("SUBSYSTEM") != "usb":
        return False
    if props.get("DEVTYPE") != "usb_device":
        return False
    if not props.get("ID_VENDOR_ID"):
        return False

    id_class = props.get("ID_USB_CLASS_FROM_DATABASE", "").lower()
    driver   = props.get("ID_USB_DRIVER", "")

    if "hub" in id_class or driver in ("hub", "usb"):
        return False

    return True


def parse_udev_block(lines: list) -> dict:
    """Parse a udevadm monitor property block into a dict."""
    props = {}
    for line in lines:
        line = line.strip()
        if "=" in line:
            key, _, val = line.partition("=")
            props[key.strip()] = val.strip()
    return props


def friendly_label(props: dict) -> str:
    """Build a human-readable device label from udev properties."""
    vendor = props.get("ID_VENDOR", "")
    model  = props.get("ID_MODEL", "")
    # Fallback to USB class description if no model string
    if not model:
        model = props.get("ID_USB_CLASS_FROM_DATABASE", "USB Device")
    label = f"{vendor} {model}".strip()
    # Replace underscores that udev uses instead of spaces
    return label.replace("_", " ")


def monitor(player, use_notify):
    """Main event loop."""
    log.info(f"usb-chime daemon started  |  player: {player}  |  notifications: {use_notify}")

    proc = subprocess.Popen(
        ["udevadm", "monitor", "--udev", "--property", "--subsystem-match=usb"],
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        text=True,
        bufsize=1,
    )

    block   = []
    action  = None
    devpath = None

    # ── Disconnect fix ─────────────────────────────────────────────────────
    # udev strips ID_VENDOR_ID etc. from "remove" events before they fire.
    # Record DEVPATH + label on connect; look it up on remove.
    known_devices: dict[str, str] = {}   # devpath → human label

    def shutdown(sig, frame):
        log.info("Shutting down.")
        proc.terminate()
        sys.exit(0)

    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGINT, shutdown)

    for raw_line in proc.stdout:
        line = raw_line.rstrip()

        # ── Blank line = end of one udev event block ──────────────────────
        if line == "":
            if block and action:
                props = parse_udev_block(block)
                path  = props.get("DEVPATH") or devpath or ""

                if action == "add" and is_real_usb_device(props):
                    label = friendly_label(props)
                    known_devices[path] = label
                    log.info(f"Connected:    {label}  [{path}]")
                    play(CONNECT_WAV, player)
                    if use_notify:
                        notify(
                            "USB Device Connected",
                            label,
                            "drive-removable-media-usb",
                        )

                elif action == "remove":
                    label = known_devices.pop(path, None)
                    if label is not None:
                        log.info(f"Disconnected: {label}  [{path}]")
                        play(DISCONNECT_WAV, player)
                        if use_notify:
                            notify(
                                "USB Device Disconnected",
                                label,
                                "drive-harddisk-usb",
                            )

            block   = []
            action  = None
            devpath = None
            continue

        # ── Header line: "UDEV  [123.45] add   /devices/... (usb)" ────────
        if line.startswith("UDEV"):
            parts = line.split()
            if len(parts) >= 3:
                action = parts[2]
            if len(parts) >= 4:
                devpath = parts[3]
            continue

        block.append(line)

    log.warning("udevadm monitor exited unexpectedly.")


def main():
    player = find_player()
    if not player:
        msg = "No audio player found. Install ffmpeg:  sudo pacman -S ffmpeg  OR  sudo apt install ffmpeg"
        log.error(msg)
        print(f"ERROR: {msg}")
        sys.exit(1)

    for f in [CONNECT_WAV, DISCONNECT_WAV]:
        if not os.path.isfile(f):
            msg = f"Missing sound file: {f}  →  re-run install.sh"
            log.error(msg)
            print(f"ERROR: {msg}")
            sys.exit(1)

    use_notify = has_notify_send()
    if not use_notify:
        log.warning("notify-send not found — desktop notifications disabled.")

    monitor(player, use_notify)


if __name__ == "__main__":
    main()
